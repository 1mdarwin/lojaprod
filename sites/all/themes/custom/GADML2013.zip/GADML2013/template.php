<?php

/**
 * @file
 * This file is empty by default because the base theme chain (Alpha & Omega) provides
 * all the basic functionality. However, in case you wish to customize the output that Drupal
 * generates through Alpha & Omega this file is a good place to do so.
 * 
 * Alpha comes with a neat solution for keeping this file as clean as possible while the code
 * for your subtheme grows. Please read the README.txt in the /preprocess and /process subfolders
 * for more information on this topic.
 */
/*
        The next function is for alter the forms like as textbox
*/

function gadml2013_form_alter(&$form, &$form_state, $form_id ){
        switch ($form_id) {
                case 'user_login_block':
                        # code...
                        $form['name']['#attributes']['placeholder'] = t('Username...');
                        $form['pass']['#attributes']['placeholder'] = t('Password...');
                        break;
                case 'search_block_form':
                        $form['search_block_form']['#attributes']['placeholder'] = t('Search...');
                        $form['search_block_form']['#attributes']['id'] = t('#search_box');
                        break;          
                
                default:
                        # code...
                        break;                  
        }

}
/*
Load the google fonts
*/
function gadml2013_preprocess_html(&$variables){
        drupal_add_css('http://fonts.googleapis.com
                /css?family=Open+Sans:400,700,400italic,700italic&
                subset=latin,cyrillic', array('type' => 'external'));
        drupal_add_js('sites/all/libraries/bxslider/jquery.bxslider.js', 'file'); 
        drupal_add_js('sites/all/libraries/bxslider/jquery.bxslider.min.js', 'file'); 
}


/*function gadml2013_links__system_main_menu($variables) {
        $output = '';
        foreach ($variables['links'] as $link) {
                $output .= l('<span>'. check_plain($link['title']) .'</span>', $link['href'], $link);
        }
        return $output;
}*/
/*function gadml2013_menu_link(array $variables) {
        $element = $variables['element'];
        $sub_menu = '';

        if ($element['#below']) {
                $sub_menu = drupal_render($element['#below']);
        }

        if ($element['#original_link']['menu_name'] == 'main-menu') {
                $linkText = '<span>' . $element['#title'] . '</span>';
                $element['#localized_options']['html'] = true;
        } else {
                $linkText = $element['#title'];
        }

        $output = l($linkText, $element['#href'], $options = $element['#localized_options']);

        return '<li' . drupal_attributes($element['#attributes']) . '>' . $output . $sub_menu . "</li>\n";
}*/
function gadml2013_menu_link__main_menu(array $variables) {
        /* Funciona para un bloque especifico */
  $element = $variables['element'];
  $sub_menu = '';

  if ($element['#below']) {
    $sub_menu = drupal_render($element['#below']);
  }

  $element['#localized_options']['html'] = TRUE;
  $linktext = $element['#title'] .'<span class="indicator"> </span>';

  $output = l($linktext, $element['#href'], $element['#localized_options']);
  return '<li' . drupal_attributes($element['#attributes']) . '>' . $output . $sub_menu . "</li>\n";
}

/* Funciona
function gadml2013_link($variables) {
  return '<a href="' . check_plain(url($variables['path'], 
        $variables['options'])) . '"' 
        . drupal_attributes($variables['options']['attributes']) 
        . '><span class="'.$variables['text'].'">' 
        . ($variables['options']['html'] ? $variables['text'] : check_plain($variables['text'])) 
        . '</span></a>';
}*/