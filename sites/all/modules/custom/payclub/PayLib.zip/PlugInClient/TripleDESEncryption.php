<?php
class TripleDESEncryption
{
	function TripleDESEncryption ()
	{

	}

	function encrypt($toEncrypt, $key, $IV)
	{
		$data = $toEncrypt;
		$key = base64_decode($key);
		$IV = base64_decode($IV);

		$dlen = strlen($data);
		$pad = 16 - fmod($dlen, 16);
		if ($pad > 0)
		{
			$i = (int)$pad;
			while ($i > 0)
			{
				$data.="\0";
				//$data.="\0";
				$i--;
			}
		}

		$cipher = mcrypt_module_open(MCRYPT_3DES,'',MCRYPT_MODE_CBC,'');

		mcrypt_generic_init($cipher, $key, $IV);
		$data = mcrypt_generic($cipher,$data);
		mcrypt_generic_deinit($cipher);

		$data = base64_encode($data);
		return $data;
	}

	function decrypt($toDecrypt, $key, $IV)
	{
		$data = $toDecrypt;
		$key = base64_decode($key);
		$IV = base64_decode($IV);
		$data = str_replace("\n", "", $data);
		dsm($data);
		dsm("Eliminando nueva linea");
		$data = str_replace("\r", "", $data);
		dsm($data);
		dsm("Eliminando retorno de carro <enter>");
		$dec = "datos=ref2&aut=131790&Cre=40&mes=1&ttar=DN&sub=1000&Iva=130&Ice=84&Int=0&Tot=1214&tNo=5785&cDt= ref1 &tipo=P";
		$data = base64_encode($dec);
		dsm($data);
//		$data = "/N7Vifp2Tbt5Vu6xr3Sa49wsRj4iDe8C3wV K64eJ we8O8o FeDfmKnmgGV74nqRPVkvoyq0GjmUAD9BW8iaPAv7R4pDlbhsaC6wcHZRKGFouHw4ZvayDNL0dRF88j gHPZH8Zt4gY88haHPrGRQ==";
//		$data = "/N7Vifp2Tbt5Vu6xr3Sa49wsRj4iDe8C3wVK64eJwe8O8oFeDfmKnmgGV74nqRPVkvoyq0GjmUAD9BW8iaPAv7R4pDlbhsaC6wcHZRKGFouHw4ZvayDNL0dRF88jgHPZH8Zt4gY88haHPrGRQ==";
//		$data = "VGhpcyBpcyBhbiBlbmNvZGVkIHN0cmluZw==";
		dsm("Datos Llenos ");
		if ( base64_encode(base64_decode($data, true)) === $data){
		    dsm('$data is valid');
		} else {
		    dsm('$data is NOT valid');
		}
		$data = base64_decode($data);
		dsm($data);
		dsm("Datos vacios");

		$cipher = mcrypt_module_open(MCRYPT_3DES,'',MCRYPT_MODE_CBC,'');

		mcrypt_generic_init($cipher, $key, $IV);
		dsm($cipher);
		$data = mdecrypt_generic($cipher,$data);
		dsm($data);
		dsm("Ready for back");
		mcrypt_generic_deinit($cipher);


		$data = str_replace("\0", "", $data);
		return $data;
	}

	function generateKey ()
	{
		return base64_encode($this->generateKeyInterna(24, 24, true, false, true));
	}

	function generateKeyInterna ($minlength, $maxlength, $useupper, $usespecial, $usenumbers)
	{
		$key = '';
		$charset = "abcdefghijklmnopqrstuvwxyz";
		if ($useupper) $charset .= "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		if ($usenumbers) $charset .= "0123456789";
		if ($usespecial) $charset .= "~@#$%^*()_+-={}|]["; // Note: using all special characters this reads: "~!@#$%^&*()_+`-={}|\\]?[\":;'><,./";
		if ($minlength > $maxlength)
			$length = mt_rand ($maxlength, $minlength);
		else
			$length = mt_rand ($minlength, $maxlength);
		for ($i=0; $i<$length; $i++) $key .= $charset[(mt_rand(0,(strlen($charset)-1)))];			
		return $key;
	}
}
?>
