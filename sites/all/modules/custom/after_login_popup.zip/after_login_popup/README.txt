After login popup
